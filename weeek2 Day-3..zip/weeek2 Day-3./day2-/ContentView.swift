

import SwiftUI

enum CardCategory{
    case Book
    case electronics
}
struct CardData: Identifiable {
    let id: UUID = UUID()
    let title: String
    let price: Int
    var category:CardCategory
    let imageURL: URL? // Optional<URL>
}
func MakeCardData() ->Array<CardData> {


    return
    Array(
        repeating:
            CardData(title: "Titel + Book",
                     price: 10,
                     category:.Book,
                     imageURL:URL(string: "https://source.unsplash.com/200x200/?book")
            ),
        count: 10
        ) +
    Array(
        repeating:
            CardData(title: "Titel + electronics",
                     price: 10,
                     category:.electronics,
                     imageURL:URL(string: "https://source.unsplash.com/200x200/?electronics")
                
            ),
        count:10
    )
}

struct CardView: View {
    let data: CardData
    var body: some View {
        GeometryReader { geometryProxy in
            ZStack{
                AsyncImage(url: data.imageURL){
                    result in
                    if let image = result.image{
                        image
                            .resizable()
                            .scaledToFill()
                    }else{
                        ProgressView()
                    }
                }
                .frame(width: geometryProxy.size.width,
                       height: geometryProxy.size.height
                )
                VStack{
                    Spacer()
                    Text(data.title)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(8)
                .foregroundColor(.white)
                .background(
                    Gradient(colors:[
                        Color.clear,
                        Color.clear,
                        Color.clear,
                        Color.black
                    ])
                    
                )
            }
            .cornerRadius(12)
            .frame(width: geometryProxy.size.width,
                   height: geometryProxy.size.height)
            
}
}
}
    
struct ContentView: View {
    let categories : Array<String> = [
        "Book",
        "electronics"
    ]
    let cards: Array<CardData> = MakeCardData()
    @State var filteredCards:Array<CardData>=[]
    @State var searchedText:String = ""
    func prepareDataForUser(){
        filteredCards = cards
    }
    var body: some View {
        NavigationStack{
            VStack {
                
                HStack {
                    Image(systemName: "swift")
                    TextField("Search", text: $searchedText)
                        .frame(height: 40)
                }
                .padding(.vertical, 8)
                .padding(.horizontal, 4)
                .background(Color.gray.opacity(0.3))
                .cornerRadius(12)
                
                ScrollView(.horizontal){
                    HStack{
                        ForEach(categories,id:
                                    \.self)
                        {categories in
                            Button(action: {
                                switch
                                categories {
                                case "Book":
                                    filteredCards=cards.filter({card in card.category == .Book})
                                case "electronics":
                                    filteredCards=cards.filter({card in card.category == .electronics})
                                default:
                                    filteredCards = cards
                                     
                                }
                            },
                                   label: {
                                Text(categories)
                                    .padding(.vertical,8)
                                    .padding(.horizontal,16)
                                    .background(Color.gray.opacity(0.3))
                                    .foregroundColor(Color.black)
                                    .cornerRadius(12)
                            })
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                ScrollView {
                    
                    CardView(
                        data: CardData(
                            title: "book and moer",
                           
                            price: 0,
                            category: .Book,
                            imageURL: URL(string: "https://source.unsplash.com/500x300/?book")
                        )
                    )
                    .frame(height: 200)
                    .clipped()
                    ScrollView(.horizontal) {
                        HStack {
                            ForEach(filteredCards){
                                card in
                                if card.category == .Book {
                                    
                                    CardView(data: card)
                                        .frame(width: 300, height: 150)
                                }
                            }
                        }
                    }
                    HStack {
                        Text("Book")
                        Spacer()
                        NavigationLink(
                            destination: {
                                Text("Hello, am second view")
                            },
                            label: {
                                Text("See All >")
                            }
                        )
                    }
                    ScrollView(.horizontal) {
                        HStack {
                            ForEach(filteredCards){
                                card in
                                if card.category == .electronics {
                                    
                                    CardView(data: card)
                                        .frame(width: 300, height: 150)
                                }
                            }
                        }
                    }
                    HStack {
                        Text("electronics")
                        Spacer()
                        NavigationLink(
                            destination: {
                                Text("Hello, am second view")
                            },
                            label: {
                                Text("See All >")
                            }
                        )
                    }
                }
                
                .padding(8)
                .frame(maxWidth: .infinity, maxHeight:.infinity)
            }
            .navigationTitle("Library")
            .navigationBarTitleDisplayMode(.inline)
            
            .onAppear{
                prepareDataForUserss()
            }
            
            .onChange(of: searchedText ){ value in
                filteredCards(value)
            }
           
        }
    }
    func prepareDataForUserss() {
        filteredCards = cards
    }
    func filteredCards(_ value :  String){
        if value.isEmpty {
            filteredCards = cards
        }else {
            filteredCards = cards.filter({ card in
                return card.title.contains(value)
                
            })
        }
    }
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}

    
